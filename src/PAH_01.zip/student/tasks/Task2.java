package student.tasks;

import java.awt.Color;
import java.util.Collection;
import java.util.LinkedList;

import javax.vecmath.Point2d;

import cz.agents.alite.pahtactical.vis.LabeledPointLayer;
import cz.agents.alite.pahtactical.vis.PathLayer;
import cz.agents.alite.pahtactical.vis.Polygons2dLayer;
import cz.agents.alite.tactical.util.Polygon2d;
import cz.agents.alite.vis.VisManager;
import cz.agents.alite.vis.layer.common.ColorLayer;
import cz.agents.alite.vis.layer.common.VisInfoLayer;

public class Task2 {
	
	/**
	 *  This method should return a "reasonable" path for a vehicle with given footprint and minimum turn radius that begins at start configuration
	 *  and ends at the goal configuration and the vehicle will avoid collisions with given polygonal obstacles. 
	 *  Use RRT* algorithm with Dubin's curve extensions. 
	 *
	 *  @return poly-line representation of the found path
	 */
	
	public static Point2d[] findPath(
			final Point2d start, final Point2d end, final Collection<Polygon2d> obstacles) {
		
		// Put your solution here...
		
		return new Point2d[0];
	}
	
	public static void main(String[] args) {		
		Point2d start = new Point2d(0, -200);
		Point2d end = new Point2d(0, 120);
		
		Collection<Polygon2d> polygons = new LinkedList<Polygon2d>();
		polygons.add(getRect(0, 0, 200, 200));
		polygons.add(getRect(100, 100, 170, 170));
		polygons.add(getRect(-100, 100, 100, 170));

		VisManager.registerLayer(ColorLayer.create(Color.WHITE));
		VisManager.registerLayer(Polygons2dLayer.create(polygons, Color.BLACK, 2));
		VisManager.registerLayer(LabeledPointLayer.create(start, "start"));
		VisManager.registerLayer(LabeledPointLayer.create(end, "end"));
		
		VisManager.registerLayer(VisInfoLayer.create());
		
        VisManager.setInitParam("PAH Trajectory Planning Task", 1024, 768);
        VisManager.init();
        
        Point2d[] path = findPath(start, end, polygons);
        
        VisManager.registerLayer(PathLayer.create(path, Color.BLUE, 3));
	}
	
	public static Polygon2d getRect(int x, int y, int w, int h) {
		return new Polygon2d(new Point2d[]{
				new Point2d(x - w/2, y -h/2),
				new Point2d(x + w/2, y -h/2),
				new Point2d(x + w/2, y +h/2),
				new Point2d(x - w/2, y +h/2)});
	}

}
